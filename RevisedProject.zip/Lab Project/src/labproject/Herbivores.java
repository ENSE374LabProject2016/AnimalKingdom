package labproject;

abstract public class Herbivores extends AnimalKingdom{

}
