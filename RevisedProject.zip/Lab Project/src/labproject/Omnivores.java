package labproject;

abstract public class Omnivores extends Herbivores {
    
    boolean eatAnimal(Object a) 
    {
        boolean result=false;
        //do smthing
        
        return result;
    }

}
