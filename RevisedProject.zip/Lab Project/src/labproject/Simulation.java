package labproject;

public class Simulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
