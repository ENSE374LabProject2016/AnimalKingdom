package labproject;

public interface Eatable {


	char getName();
	boolean canBeAteBy(Eatable e);
	
}
