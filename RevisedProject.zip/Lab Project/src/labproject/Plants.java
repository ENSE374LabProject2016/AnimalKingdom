package labproject;

abstract public class Plants extends AnimalKingdom {
    Plants()
    {
        
        this.setLifeLimit(50); 
    }
    

}
