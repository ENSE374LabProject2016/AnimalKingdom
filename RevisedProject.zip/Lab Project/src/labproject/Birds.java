package labproject;

abstract public class Birds extends Omnivores {
   
  
}
